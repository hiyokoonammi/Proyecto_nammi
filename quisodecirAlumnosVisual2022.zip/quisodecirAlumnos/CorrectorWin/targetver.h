#pragma once

// La inclusi�n de SDKDDKVer.h define la plataforma m�s alta de Windows disponible.

// Si desea compilar la aplicaci�n para una plataforma anterior de Windows, incluya WinSDKVer.h y
// establezca la macro _WIN32_WINNT en la plataforma que desea admitir antes de incluir SDKDDKVer.h.

#include <SDKDDKVer.h>
